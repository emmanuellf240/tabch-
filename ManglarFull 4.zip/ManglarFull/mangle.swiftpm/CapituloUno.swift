//
//  CapituloUno.swift
//  mangle
//
//  Created by ADMIN UNACH on 02/03/24.
//

import SwiftUI

struct CapituloUno: View {
    
    @State private var showMenu=false
    @State private var showDos=false
    @State private var opaCruz: Double=0.0
    @State private var opaHoja: Double=0.0
    @State private var opaCiclo: Double=0.0
    @State private var opaRaiz: Double=0.0
    
    @State private var iterador=0
    @State private var Chat = ["Hola!! mi nombre es Mateo Rhizophora Mangle...", "Soy una de las muchas especies que conformamos el manglar", "Somos muy altos  y nuestros cuerpos son fuertes con raíces sumergidas en el agua salada...", "Prosperamos en condiciones calientes, fangosas y saladas."]
    var body: some View {
        ZStack{
            
            
            Rectangle()
                                      .foregroundColor(.clear)
                                      .frame(width: 1030, height: 1194)
                                      .background(
                                        Image("FondoDos")
                                          .resizable()
                                          .aspectRatio(contentMode: .fill)
                                          .frame(width: 840, height: 1204)
                                          .clipped()
                                      )
            
            Text("Capitulo I")
              .font(Font.custom("Nunito Sans", size: 24))
              .foregroundColor(.black)
              .offset(x: 0, y: -560)
            
            Text("Un nuevo amigo")
              .font(Font.custom("Otomanopee One", size: 48))
              .multilineTextAlignment(.center)
              .foregroundColor(.black)
              .frame(width: 437, height: 89, alignment: .center).offset(x: 0, y: -520)
            
            
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 60, height: 60)
              .background(
                Image("FlechaDerecha")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 60, height: 60)
                  .clipped().offset(x: 350, y: -520)
                
              ).onTapGesture {
                  showDos.toggle()
              }.fullScreenCover(isPresented: $showDos){
                  
                  CapituloDos()
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 60, height: 60)
              .background(
                Image("Casa")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 60, height: 60)
                  .clipped().offset(x: -300, y: -520)
              ).onTapGesture {
                  showMenu.toggle()
              }.fullScreenCover(isPresented: $showMenu){
                  
                  inicio()
              }
            
            //534, 248
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 130, height: 142.93878)
              .background(
                Image("FondoChat")
                    .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 430.77307, height: 165)
                  .clipped().offset(x: 0, y: -340)
              )
            
            Text("\(Chat[iterador])")
                .font(Font.custom("Nunito Sans", size: 25))
                .foregroundColor(.black).bold()
                .frame(width: 350, height: 177, alignment: .leading).offset(x: 10, y: -340)
            
            
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 130, height: 142.93878)
              .background(
                Image("Chat")
                    .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 430.77307, height: 167.93878)
                  .clipped().offset(x: 0, y: -340)
              )
            
            
            
            Rectangle()
                          .foregroundColor(.clear)
                          .frame(width: 35, height: 25)
                          .background(
                            Image(systemName: "arrowshape.turn.up.forward.fill")
                              .resizable()
                              .aspectRatio(contentMode: .fill)
                              .frame(width: 35, height: 25)
                              .clipped().offset(x: 150, y: -284)
                            
                          ).onTapGesture {
                              
                              if (iterador<3){
                                  iterador+=1
                              }else{
                                  
                              }
                          }.foregroundColor(.black)
            
            
            
            
            Rectangle()
            .foregroundColor(.clear)
            .frame(width: 300, height: 300)
            .background(
            Image("ChibiDos")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 250, height: 250)
            .clipped().offset(x: 290, y: -226)
            )
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 160, height: 160)
              .background(
                Image("Cruz")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 100, height: 100)
                  .clipped().offset(x: -300, y: -200)
              ).onTapGesture {
                  if (opaCruz==10.0){
                      opaCruz=0.0
                  }else{
                      
                      opaCruz=10.0
                      
                  }
                  
                  
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 130, height: 142.93878)
              .background(
                Image("FondoChat")
                    .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 430.77307, height: 165)
                  .clipped().offset(x: 60, y: 60).rotationEffect(.degrees(180))
              ).opacity(opaCruz)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 130, height: 142.93878)
              .background(
                Image("Chat")
                    .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 430.77307, height: 167.93878)
                  .clipped().offset(x: 60, y: 60).rotationEffect(.degrees(180))
              ).opacity(opaCruz)
            
            Text("Hojas medicinales: Ayudan al tratamiento de ciertas enfermedades.")
                .font(Font.custom("Nunito Sans", size: 25))
                .foregroundColor(.black).bold()
                .frame(width: 340, height: 177, alignment: .leading).offset(x: -50, y: -65).opacity(opaCruz)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 160, height: 160)
              .background(
                Image("Hojas")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 100, height: 100)
                  .clipped().offset(x: -260, y: 100)
              ).onTapGesture {
                  
                  if (opaHoja==10.0){
                      opaHoja=0.0
                  }else{
                      opaHoja=10.0
                  }
                  
                  
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 130, height: 142.93878)
              .background(
                Image("FondoChat")
                    .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 430, height: 165)
                  .clipped().offset(x: 10, y: -160).rotationEffect(.degrees(180))
              ).opacity(opaHoja)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 130, height: 142.93878)
              .background(
                Image("Chat")
                    .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 430.77307, height: 167.93878)
                  .clipped().offset(x: 10, y: -160).rotationEffect(.degrees(180))
              ).opacity(opaHoja)
            
            Text("Filtración de contaminantes: Hace que el agua sea más limpia.")
                .font(Font.custom("Nunito Sans", size: 25))
                .foregroundColor(.black).bold()
                .frame(width: 340, height: 177, alignment: .leading).offset(x: 0, y: 150).opacity(opaHoja)
            
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 160, height: 160)
              .background(
                Image("Ciclo")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 100, height: 100)
                  .clipped().offset(x: 40, y: 280)
              ).onTapGesture {
                  if (opaCiclo==10.0){
                      opaCiclo=0.0
                  }else{
                      opaCiclo=10.0
                  }
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 130, height: 142.93878)
              .background(
                Image("FondoChat")
                    .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 430, height: 165)
                  .clipped().offset(x: -200, y: -360).rotationEffect(.degrees(180))
              ).opacity(opaCiclo).scaleEffect(x: -1, y: 1)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 130, height: 142.93878)
              .background(
                Image("Chat")
                    .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 430.77307, height: 167.93878)
                  .clipped().offset(x: -200, y: -360).rotationEffect(.degrees(180))
              ).opacity(opaCiclo).scaleEffect(x: -1, y: 1)
            
            Text("Ciclo de nutrientes: Permite el ciclo de elementos básicos para la vida.")
                .font(Font.custom("Nunito Sans", size: 25))
                .foregroundColor(.black).bold()
                .frame(width: 340, height: 177, alignment: .leading).offset(x: -200, y: 360).opacity(opaCiclo)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 160, height: 160)
              .background(
                Image("RaizC")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 100, height: 100)
                  .clipped().offset(x: 330, y: 380)
              ).onTapGesture {
                  if ( opaRaiz==10.0){
                      opaRaiz=0.0
                  }else{
                      opaRaiz=10.0
                  }
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 130, height: 142.93878)
              .background(
                Image("FondoChat")
                    .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 430, height: 165)
                  .clipped().offset(x: 100, y: -500).rotationEffect(.degrees(180))
              ).opacity(opaRaiz).scaleEffect(x: -1, y: 1)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 130, height: 142.93878)
              .background(
                Image("Chat")
                    .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 430.77307, height: 167.93878)
                  .clipped().offset(x: 100, y: -500).rotationEffect(.degrees(180))
              ).opacity(opaRaiz).scaleEffect(x: -1, y: 1)
            
            Text("Las raíces: las raíces de los árboles mantiene firme el suelo y reduciendo su deterioro.")
                .font(Font.custom("Nunito Sans", size: 25))
                .foregroundColor(.black).bold()
                .frame(width: 340, height: 177, alignment: .leading).offset(x: 120, y: 500).opacity(opaRaiz)

            
        }.frame(width: 834, height: 1194)
            .background(Color(red: 0.95, green: 0.95, blue: 0.86))
        
        
            
        
    }
}

#Preview {
    CapituloUno()
}
