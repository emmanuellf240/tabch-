//
//  CapituloCuatro.swift
//  mangle
//
//  Created by Fernando Cruz Hernández on 07/03/24.
//

import SwiftUI

struct CapituloCuatro: View {
    
    @State private var offsetX: CGFloat = -320
    @State private var seMovio: Bool = false
    @State private var seAparece: Bool = false
    @State private var opacidad: Double = 0.0
    @State private var showMenu=false
    @State private var showCinco=false
    @State private var showTres=false
    @State private var iterador=0
    @State private var Chat = ["Hola! Mi nombre es Leo...", "Los mangles son escudos poderosos, nos protegen en contra de las mareas altas o los climas extremos ...", "Por ejemplo las tormentas, inundaciones incluso tsunamis!!...", "Los manglares reducen su fuerza y evitan un golpe directo."]
    
    var body: some View {
        ZStack {
            Text("Capitulo IV")
              .font(Font.custom("Nunito Sans", size: 24))
              .foregroundColor(.black)
              .offset(x: 0, y: -560)
            
            Text("El escudero")
              .font(Font.custom("Otomanopee One", size: 48))
              .multilineTextAlignment(.center)
              .foregroundColor(.black)
              .frame(width: 437, height: 89, alignment: .center).offset(x: 0, y: -520)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 60, height: 60)
              .background(
                Image("FlechaIzquierda")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 60, height: 60)
                  .clipped().offset(x: -350, y: -520)
              ).onTapGesture {
                  showTres.toggle()
              }.fullScreenCover(isPresented: $showTres){
                  
                  CapituloTres()
                  
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 60, height: 60)
              .background(
                Image("FlechaDerecha")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 60, height: 60)
                  .clipped().offset(x: 350, y: -520)
                
              ).onTapGesture {
                  showCinco.toggle()
              }.fullScreenCover(isPresented: $showCinco){
                  CapituloCinco()
              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 60, height: 60)
              .background(
                Image("Casa")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 60, height: 60)
                  .clipped().offset(x: -270, y: -520)
              ).onTapGesture {
                  showMenu.toggle()
              }.fullScreenCover(isPresented: $showMenu){
                  
                  inicio()
              }
            
            Rectangle()
                .foregroundColor(.clear)
                .frame(width: 1040, height: 305)
                .background(
                    Image("AguaDos")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 1040, height: 305)
                        .clipped()
                        
                ).offset(x: 0, y: 445)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 614.2478, height: 263.17059)
              .background(
                Image("Arena")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 614.247802734375, height: 263.17059326171875)
                  .clipped()
              ).offset(x: 110, y: 463)
              
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 144, height: 163)
              .background(
                Image("CasaUno")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 144, height: 163)
                  .clipped()
              ).offset(x: 140, y: 450)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 144, height: 163)
              .background(
                Image("CasaDos")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 164, height: 163)
                  .clipped()
              ).offset(x: 320, y: 420)
            
            Button(action: {
                        withAnimation(.easeInOut(duration: 2)) {
                            if seMovio {
                                offsetX = -320
                            } else {
                                offsetX = -100
                            }
                            seMovio.toggle()
                        }
                    }) {
                        Text(seMovio ? "Mover de nuevo" : "Mover")
                    }.font(.title).foregroundColor(.black).bold().frame(width: 247, height: 100, alignment: .center).background(Color(red: 0.45, green: 0.72, blue: 0.52))
                .cornerRadius(300)
                .shadow(color:.black.opacity(0.2),radius: 2, x: 0, y: 2)
                .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 1)
                .shadow(color: .black.opacity(0.14), radius: 2.5, x: 0, y: 4)
            
            Button(action: {
                        withAnimation(.easeInOut(duration: 1)) {
                            if seAparece {
                                opacidad = 0.0
                            } else {
                                opacidad = 100.0
                            }
                            seAparece.toggle()
                        }
                    }) {
                        Text(seAparece ? "Desproteger" : "Proteger")
                    }.font(.title).foregroundColor(.black).bold().frame(width: 200, height: 100, alignment: .center).background(Color(red: 0.31, green:0.78, blue: 0.74))
                .cornerRadius(300)
                .shadow(color:.black.opacity(0.2),radius: 2, x: 0, y: 2)
                .shadow(color: .black.opacity(0.12), radius: 5, x: 0, y: 1)
                .shadow(color: .black.opacity(0.14), radius: 2.5, x: 0, y: 4).offset(x: 0, y: 150)
                    
            
            Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 144, height: 163)
                        .background(
                            Image("Ola")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 204, height: 163)
                                .clipped()
                        )
                        .offset(x: offsetX, y: 430)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 400, height: 348.95834)
              .background(
                Image("niño")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 400, height: 408.9583435058594)
                  .clipped().offset(x: -230, y: 0)
              )
            
            Rectangle()
                .foregroundColor(.clear)
                .frame(width: 752, height: 288)
                .background(
                    Image("Chat")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 752, height: 288)
                        .clipped().offset(x: 0, y: -340)
                    
                ).scaleEffect(x: -1, y: 1)
            
            Text("\(Chat[iterador])")
                .font(Font.custom("Nunito Sans", size: 35))
                .foregroundColor(.black)
                .frame(width: 551, height: 177, alignment: .leading)
                .offset(x: 0, y: -340)
            
            

            Rectangle()
                              .foregroundColor(.clear)
                              .frame(width: 40, height: 30)
                              .background(
                                Image(systemName: "arrowshape.turn.up.forward.fill")
                                  .resizable()
                                  .aspectRatio(contentMode: .fill)
                                  .frame(width: 40, height: 30)
                                  .clipped().offset(x: -280, y: -230).foregroundColor(.black)
                                
                              ).onTapGesture {
                                  
                                  if (iterador<3){
                                      iterador+=1
                                  }else{
                                      
                                  }
                              }
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 217, height: 217)
              .background(
                Image("ManglaresProtege")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 267, height: 217)
                  .clipped()
              ).offset(x: -70, y: 400).opacity(opacidad)
            
            
            
            
        }
        .frame(width: 834, height: 1194)
        .background(Color(red: 0.95, green: 0.95, blue: 0.86))
    }
}

#Preview {
    CapituloCuatro()
}
