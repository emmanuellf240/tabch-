//
//  MangleApp.swift
//  Mangle
//
//  Created by ADMIN UNACH on 02/03/24.
//

import SwiftUI

@main

struct MangleApp: App {
    var body: some Scene {
        WindowGroup {
            Inicio()
        }
    }
}
