//
//  Inicio.swift
//  Mangle
//
//  Created by ADMIN UNACH on 02/03/24.
//

import SwiftUI

struct Inicio: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Inicio()
}
